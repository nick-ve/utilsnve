             abc2mtex for Windows
             ====================

This .zip archive contains all elements to use
(or install) the abc2mtex facility.
Just unzip the archive and install the various
.exe files in a directory which is contained
in your path. This will allow you to run the various
abc2mtex facilities on windows machines in order to
convert music scores from abc format to MusiXTex.
Note that you need to have LaTeX (incl. MusiXTex)
installed on your system.

The various .exe files included in the archive are :

abc2mtex.exe
abcsort_in.exe (was named originally sort_in.exe)
abcsearch.exe  (was named originally search.exe)

The current .exe files have been created on WinXP
using MSVC++ version 7.
In case (one of) the .exe facilities doesn't function
properly, you can create the corresponding .exe file
yourself via :

cl -o abc2mtex fields.c abc.c tex.c index.c
cl -o abcsort_in sort_in.c index.c
cl -o abcsearch search.c abc.c tex.c index.c

I have extended the standard ABC functionality via
the included header.tex file. See the docs in this
file for a specification of the extra features.
This new header file uses my private LaTeX class (nveart.cls)
for writing scientific articles. This nveart.cls is included
in this distribution as well.
The original abc2mtex header file is kept in header-orig.txt.

Details about the ABC format and the (use of the) abc2mtex
facility can be found in the userguide.ps which is also
included in this .zip archive. 

Nick van Eijndhoven 19-nov-2007 Utrecht University.
